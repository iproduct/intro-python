package example.hellosecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
